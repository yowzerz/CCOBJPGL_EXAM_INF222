package com.example.bike;

import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.util.Objects;


public class AdminController {
    @FXML
    private TextField usernameField, emailField, contactField;

    @FXML
    private Button editButton, deleteButton, loadButton, searchButton;

    @FXML
    private TableView<Person> customerTable;

    @FXML
    private TableColumn<Person, String> usernameColumn, emailColumn, contactColumn;

    @FXML
    private void loadButtonOnClick() {
        // Gets the user data from a file and loads it into the table
        File file = new File(getClass().getResource("users.txt").getFile());
        if(!file.exists()) {
            try {
                file.createNewFile();
                System.out.println(file.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        // Required to store data and upload to the table
        ObservableList<Person> users = FXCollections.observableArrayList();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            // Go through each line and split the data by commas, load into a class to be uploaded to users
            while((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                String username = userData[0];
                String email = userData[2];
                String contact = userData[3];

                Person person = new Person(username, email, contact);
                users.add(person);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // For class in the users list, get the respective properties to be uploaded to the table.
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        contactColumn.setCellValueFactory(new PropertyValueFactory<>("contactNumber"));

        customerTable.setItems(users);
    }

    @FXML
    private void deleteButtonOnClick() {
        /*
        Deletes everything by emptying the file and refreshing the table.
         */
        File file = new File(Objects.requireNonNull(getClass().getResource("users.txt")).getFile());

        try {
            FileWriter writer = new FileWriter(file, false);
            writer.write("");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Deleted all users");
        loadButtonOnClick();
    }

    @FXML
    private void searchButtonOnClick() {
        /*
        Linearly goes through each data and find the data with that username then displays it.
         */
        ObservableList<Person> users = customerTable.getItems();
        for(Person person : users) {
            if(person.getUsername().equals(usernameField.getText())) {
                usernameField.setText(person.getUsername());
                emailField.setText(person.getEmail());
                contactField.setText(person.getContactNumber());
                break;
            }
        }

        System.out.println("User not found.");
    }

    @FXML
    private void editButtonOnClick() {
        // Not permanent, only changes the data in the table. Pag database kaya mag store permanently
        ObservableList<Person> users = customerTable.getItems();
        for(Person person : users) {
            if(person.getUsername().equals(usernameField.getText())) {
                person.email = emailField.getText();
                person.contactNumber = contactField.getText();
                customerTable.refresh();
                break;
            }
        }

        System.out.println("User not found.");
    }
}
