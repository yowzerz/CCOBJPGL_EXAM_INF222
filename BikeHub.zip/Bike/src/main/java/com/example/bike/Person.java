package com.example.bike;

/*
 * Person class to store user information
 */

public class Person {
    public String username;
    public String email;
    public String contactNumber;

    public Person(String username, String email, String contactNumber) {
        this.username = username;
        this.email = email;
        this.contactNumber = contactNumber;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getContactNumber() {
        return contactNumber;
    }
}
