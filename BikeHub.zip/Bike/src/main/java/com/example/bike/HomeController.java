package com.example.bike;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import javafx.scene.Scene;
import javafx.stage.Stage;

public class HomeController {
    @FXML
    private Button orderButton;

    @FXML
    private void orderButtonOnClick() {
        // Gets the stage and sets the scene to order.fxml
        Stage stage = (Stage) orderButton.getScene().getWindow();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("order.fxml")));
        } catch (Exception e) {
            e.printStackTrace();
        }

        stage.setScene(scene);
    }
}
