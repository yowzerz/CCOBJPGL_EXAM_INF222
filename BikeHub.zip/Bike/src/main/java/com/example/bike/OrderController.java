package com.example.bike;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class OrderController {
    @FXML
    private TextField searchField, nameField, priceField;

    @FXML
    private ChoiceBox<String> paymentBox;

    private final ObservableList<String> paymentList = FXCollections.observableArrayList("Cash On Delivery", "Credit Card", "Debit Card");

    @FXML
    private void initialize() {
        paymentBox.setItems(paymentList);
    }

    // Go through each line and split the data by commas, load into a class to be uploaded to users
    @FXML
    private void searchButtonOnClick() {
        File file = new File(getClass().getResource("bikes.txt").getFile());
         try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = reader.readLine()) != null) {
                String[] bikeData = line.split(",");
                String name = bikeData[0];
                String price = bikeData[1];

                if(name.equals(searchField.getText())) {
                    nameField.setText(name);
                    priceField.setText(price);
                }
            }
        } catch (Exception e) {e.printStackTrace();}
    }

    @FXML
    private void orderButtonOnClick() {
        // If implemented, redirects to a receipt to show the name, price, payment etc.
        String name = nameField.getText();
        String price = priceField.getText();
        String payment = paymentBox.getValue();

        System.out.println("Name: " + name);
        System.out.println("Price: " + price);
        System.out.println("Payment: " + payment);
    }
}
