package com.example.bike;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;

public class LoginController {
    @FXML
    private TextField usernameField, passwordField;

    @FXML
    private Button signUpButton, loginButton;

    @FXML
    private void setSignUpButtonOnClick() {
        // Gets the stage and sets the scene to registration.fxml
        Stage stage = (Stage) signUpButton.getScene().getWindow();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("register.fxml")));
        } catch (Exception e) {
            e.printStackTrace();
        }

        stage.setScene(scene);
    }

    @FXML
    private void loginButtonOnClick() throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();

        /* We check if one of them is true. If normal login is true, then we move to home.fxml
        If admin login is true, then we move to admin.fxml
         */
        boolean loginSuccessful = false;
        boolean adminLogin = false;

        File users = new File(getClass().getResource("users.txt").getFile());
        if(!users.exists()) {
            users.createNewFile();
        }

        try(BufferedReader reader = new BufferedReader(new FileReader(users))){
            String line;
            // We set the admin username and password
            String adminUsername = "admin";
            String adminPassword = "admin";
            while((line = reader.readLine()) != null){
                String[] userData = line.split(",");
                String savedUsername = userData[0];
                String savedPassword = userData[1];

                // If user input admin credentials, flag for admin redirect
                if(adminUsername.equals(username) && adminPassword.equals(password)){
                    System.out.println("Admin detected.");

                    adminLogin = true;
                    break;
                }
                // Kung hindi, flag for normal redirect
                if(savedUsername.equals(username) && savedPassword.equals(password)){
                    System.out.println("Login Successful");

                    loginSuccessful = true;
                    break;
                }
            }

        } catch (FileNotFoundException fileException) {
            System.out.println("File not found");
            fileException.printStackTrace();
        }

        // Check flags for order or admin redirect respectively. Kung wala, walang mangyayari
        if(loginSuccessful) {
            Stage stage = (Stage) loginButton.getScene().getWindow();
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("home.fxml")));
            stage.setScene(scene);
        } else if (adminLogin) {
            Stage stage = (Stage) loginButton.getScene().getWindow();
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("admin.fxml")));
            stage.setScene(scene);
        }
    }
}