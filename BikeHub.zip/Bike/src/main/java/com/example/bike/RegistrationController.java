package com.example.bike;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class RegistrationController {

    @FXML
    private TextField usernameField, passwordField, emailField, contactField;

    @FXML
    private Button registerButton, loginButton;

    @FXML
    private void registerButtonOnClick() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String email = emailField.getText();
        String contact = contactField.getText();

        try {
            // maraming rewrites para sa permanent save and current working save.
            File file = new File("src/main/resources/com/example/bike/users.txt");
            File currentFile = new File(getClass().getResource("users.txt").getFile());
            FileWriter writer = new FileWriter(file, true);
            FileWriter currentWriter = new FileWriter(currentFile, true);
            writer.write(username + "," + password + "," + email + "," + contact + "\n");
            currentWriter.write( username + "," + password + "," + email + "," + contact + "\n");
            writer.close();
            currentWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        switchToLogin();
    }
    @FXML
    private void switchToLogin() {
        // Gets the stage and sets the scene to login.fxml
        FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
        Stage stage = (Stage) registerButton.getScene().getWindow();
        Scene scene = null;
        try {
            scene = new Scene(loader.load());
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
}
